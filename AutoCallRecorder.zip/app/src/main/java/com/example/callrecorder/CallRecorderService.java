package com.example.callrecorder;

import android.app.Service;
import android.content.Intent;
import android.media.MediaRecorder;
import android.os.Environment;
import android.os.IBinder;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

import java.io.IOException;

public class CallRecorderService extends Service {
    private MediaRecorder recorder;
    private TelephonyManager telephonyManager;
    private boolean isRecording = false;

    @Override
    public void onCreate() {
        super.onCreate();
        telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);

        telephonyManager.listen(new PhoneStateListener() {
            @Override
            public void onCallStateChanged(int state, String incomingNumber) {
                if (state == TelephonyManager.CALL_STATE_OFFHOOK && !isRecording) {
                    startRecording();
                } else if (state == TelephonyManager.CALL_STATE_IDLE && isRecording) {
                    stopRecording();
                }
            }
        }, PhoneStateListener.LISTEN_CALL_STATE);
    }

    private void startRecording() {
        recorder = new MediaRecorder();
        recorder.setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        String filePath = Environment.getExternalStorageDirectory().getAbsolutePath()
                + "/CallRecorder_" + System.currentTimeMillis() + ".3gp";
        recorder.setOutputFile(filePath);

        try {
            recorder.prepare();
            recorder.start();
            isRecording = true;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void stopRecording() {
        try {
            recorder.stop();
            recorder.release();
        } catch (Exception e) {
            e.printStackTrace();
        }
        isRecording = false;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}